package com.tap.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.tap.dao.OrderItemDAO;
import com.tap.model.OrderItem;

public class OrderItemDAOImpl implements OrderItemDAO {

    private static final String URL =
        "jdbc:mysql://localhost:3306/food_delivery_app?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "root";

    @Override
    public int addOrderItem(OrderItem item) {

        int result = 0;

        String sql =
            "INSERT INTO order_item (order_id, menu_id, quantity, item_price) VALUES (?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, item.getOrderId());
            ps.setInt(2, item.getMenuId());
            ps.setInt(3, item.getQuantity());
            ps.setDouble(4, item.getItemTotal()); 

            result = ps.executeUpdate();
            System.out.println(" OrderItem inserted: " + result);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
