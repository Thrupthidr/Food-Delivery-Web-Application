package com.tap.dao.impl;

import java.sql.*;
import java.util.*;

import com.tap.dao.UserDAO;
import com.tap.model.User;

public class UserDAOImpl implements UserDAO {

  
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final String URL =
        "jdbc:mysql://localhost:3306/food_delivery_app?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "root";

    // ================= ADD USER =================
    @Override
    public int addUser(User user) {

        int result = 0;
        String sql =
            "INSERT INTO users (username,password,email,address,phone_number,role,last_login_date,created_date) " +
            "VALUES (?,?,?,?,?,?,?,?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            Timestamp ts = new Timestamp(System.currentTimeMillis());

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getPhoneNumber());
            ps.setString(6, user.getRole());
            ps.setTimestamp(7, ts);
            ps.setTimestamp(8, ts);

            result = ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // ================= GET USER BY EMAIL =================
    @Override
    public User getUserByEmail(String email) {

        User user = null;
        String sql = "SELECT * FROM users WHERE email=?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = mapUser(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // ================= GET USER BY ID =================
    @Override
    public User getUser(int userId) {

        User user = null;
        String sql = "SELECT * FROM users WHERE user_id=?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = mapUser(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // ================= UPDATE USER =================
    @Override
    public int updateUser(User user) {

        int result = 0;
        String sql =
            "UPDATE users SET username=?, password=?, email=?, address=?, phone_number=?, role=? WHERE user_id=?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getPhoneNumber());
            ps.setString(6, user.getRole());
            ps.setInt(7, user.getUserId());

            result = ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // ================= DELETE USER =================
    @Override
    public void deleteUser(int userId) {

        String sql = "DELETE FROM users WHERE user_id=?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= GET ALL USERS =================
    @Override
    public List<User> getAllUsers() {

        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                users.add(mapUser(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }

    // ================= HELPER METHOD =================
    private User mapUser(ResultSet rs) throws SQLException {

        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        user.setAddress(rs.getString("address"));
        user.setPhoneNumber(rs.getString("phone_number"));
        user.setRole(rs.getString("role"));
        user.setLastLoginDate(rs.getTimestamp("last_login_date"));
        user.setCreatedDate(rs.getTimestamp("created_date"));
        return user;
    }
}
