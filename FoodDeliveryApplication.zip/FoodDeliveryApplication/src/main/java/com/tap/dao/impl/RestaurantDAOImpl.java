package com.tap.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.RestaurantDAO;
import com.tap.model.Restaurant;

public class RestaurantDAOImpl implements RestaurantDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/food_delivery_app";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    // ================= ADD RESTAURANT =================
    @Override
    public int addRestaurant(Restaurant restaurant) {

        int result = 0;

        String INSERT_QUERY =
            "INSERT INTO restaurant (restaurant_name, address, rating) VALUES (?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

            ps.setString(1, restaurant.getRestaurantName());
            ps.setString(2, restaurant.getAddress());
            ps.setDouble(3, restaurant.getRating());

            result = ps.executeUpdate();

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    // ================= GET RESTAURANT BY ID =================
    @Override
    public Restaurant getRestaurant(int restaurantId) {

        Restaurant restaurant = null;

        String SELECT_QUERY =
            "SELECT restaurant_id, restaurant_name, address, rating FROM restaurant WHERE restaurant_id = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            PreparedStatement ps = con.prepareStatement(SELECT_QUERY);
            ps.setInt(1, restaurantId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                restaurant = new Restaurant();
                restaurant.setRestaurantId(rs.getInt("restaurant_id"));
                restaurant.setRestaurantName(rs.getString("restaurant_name"));
                restaurant.setAddress(rs.getString("address"));
                restaurant.setRating(rs.getDouble("rating"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return restaurant;
    }

    // ================= UPDATE RESTAURANT =================
    @Override
    public int updateRestaurant(Restaurant restaurant) {

        int result = 0;

        String UPDATE_QUERY =
            "UPDATE restaurant SET restaurant_name = ?, address = ?, rating = ? WHERE restaurant_id = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            PreparedStatement ps = con.prepareStatement(UPDATE_QUERY);

            ps.setString(1, restaurant.getRestaurantName());
            ps.setString(2, restaurant.getAddress());
            ps.setDouble(3, restaurant.getRating());
            ps.setInt(4, restaurant.getRestaurantId());

            result = ps.executeUpdate();

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    // ================= DELETE RESTAURANT =================
    @Override
    public void deleteRestaurant(int restaurantId) {

        String DELETE_QUERY = "DELETE FROM restaurant WHERE restaurant_id = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            PreparedStatement ps = con.prepareStatement(DELETE_QUERY);
            ps.setInt(1, restaurantId);

            ps.executeUpdate();

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= GET ALL RESTAURANTS =================
    @Override
    public List<Restaurant> getAllRestaurants() {

        List<Restaurant> list = new ArrayList<>();

        String SELECT_ALL =
            "SELECT restaurant_id, restaurant_name, address, rating FROM restaurant";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            PreparedStatement ps = con.prepareStatement(SELECT_ALL);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Restaurant restaurant = new Restaurant();
                restaurant.setRestaurantId(rs.getInt("restaurant_id"));
                restaurant.setRestaurantName(rs.getString("restaurant_name"));
                restaurant.setAddress(rs.getString("address"));
                restaurant.setRating(rs.getDouble("rating"));

                list.add(restaurant);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
