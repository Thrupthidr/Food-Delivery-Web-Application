package com.tap.dao;

import java.util.List;
import com.tap.model.User;

public interface UserDAO {

    int addUser(User user);

    User getUser(int userId);

    int updateUser(User user);

    User getUserByEmail(String email);

    void deleteUser(int userId);

    List<User> getAllUsers();
}
