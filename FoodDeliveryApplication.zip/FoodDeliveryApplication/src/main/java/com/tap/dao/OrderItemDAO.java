package com.tap.dao;

import com.tap.model.OrderItem;

public interface OrderItemDAO {

    int addOrderItem(OrderItem item);
}
