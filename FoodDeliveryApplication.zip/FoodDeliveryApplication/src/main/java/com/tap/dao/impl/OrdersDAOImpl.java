package com.tap.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.OrdersDAO;
import com.tap.model.Orders;

public class OrdersDAOImpl implements OrdersDAO {

    private static final String URL =
        "jdbc:mysql://localhost:3306/food_delivery_app?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "root";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int addOrder(Orders order) {

        int orderId = 0;

        String sql =
            "INSERT INTO orders (user_id, restaurant_id, total_amount, delivery_address, payment_method, order_status) " +
            "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps =
                 con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, order.getUserId());
            ps.setInt(2, order.getRestaurantId());
            ps.setDouble(3, order.getTotalAmount());
            ps.setString(4, order.getDeliveryAddress());
            ps.setString(5, order.getPaymentMethod());
            ps.setString(6, order.getOrderStatus());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                orderId = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orderId;
    }

    @Override
    public Orders getOrder(int orderId) {
        return null;
    }

    @Override
    public List<Orders> getOrdersByUser(int userId) {

        List<Orders> ordersList = new ArrayList<>();

        String sql = "SELECT * FROM orders WHERE user_id=? ORDER BY order_date DESC";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Orders order = new Orders();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setRestaurantId(rs.getInt("restaurant_id"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                order.setDeliveryAddress(rs.getString("delivery_address"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setOrderStatus(rs.getString("order_status"));

                ordersList.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ordersList;
    }
}
