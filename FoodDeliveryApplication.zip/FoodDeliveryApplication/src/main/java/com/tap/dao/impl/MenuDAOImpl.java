package com.tap.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.MenuDAO;
import com.tap.model.Menu;

public class MenuDAOImpl implements MenuDAO {

    @Override
    public int addMenu(Menu menu) {

        int result = 0;

        String INSERT_QUERY =
            "INSERT INTO menu " +
            "(restaurant_id, menu_name, description, price, rating, image_url, dish_type, is_available) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/food_delivery_app",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

            ps.setInt(1, menu.getRestaurantId());
            ps.setString(2, menu.getMenuName());
            ps.setString(3, menu.getDescription());
            ps.setDouble(4, menu.getPrice());
            ps.setDouble(5, menu.getRating());
            ps.setString(6, menu.getImageUrl());
            ps.setString(7, menu.getDishType());
            ps.setBoolean(8, menu.isAvailable());

            result = ps.executeUpdate();

            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    @Override
    public Menu getMenu(int menuId) {
        Menu menu = null;

        String query = "SELECT * FROM menu WHERE menu_id = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/food_delivery_app",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, menuId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                menu = new Menu();
                menu.setMenuId(rs.getInt("menu_id"));
                menu.setRestaurantId(rs.getInt("restaurant_id"));
                menu.setMenuName(rs.getString("menu_name"));
                menu.setDescription(rs.getString("description"));
                menu.setPrice(rs.getDouble("price"));
                menu.setRating(rs.getDouble("rating"));
                menu.setImageUrl(rs.getString("image_url"));
                menu.setDishType(rs.getString("dish_type"));
                menu.setAvailable(rs.getBoolean("is_available"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return menu;
    }


    @Override
    public List<Menu> getMenusByRestaurant(int restaurantId) {

        List<Menu> menuList = new ArrayList<>();

        String SELECT_QUERY =
                "SELECT * FROM menu WHERE restaurant_id = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/food_delivery_app",
                    "root",
                    "root"
            );

            PreparedStatement ps =
                    con.prepareStatement(SELECT_QUERY);
            ps.setInt(1, restaurantId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Menu menu = new Menu();
                menu.setMenuId(rs.getInt("menu_id"));
                menu.setRestaurantId(rs.getInt("restaurant_id"));
                menu.setMenuName(rs.getString("menu_name"));
                menu.setDescription(rs.getString("description"));
                menu.setPrice(rs.getDouble("price"));
                menu.setRating(rs.getDouble("rating"));
                menu.setImageUrl(rs.getString("image_url"));
                menu.setDishType(rs.getString("dish_type"));
                menu.setAvailable(rs.getBoolean("is_available"));

                menuList.add(menu);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return menuList;
    }
}
