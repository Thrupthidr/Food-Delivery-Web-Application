package com.tap.model;

public class Restaurant {

    private int restaurantId;
    private String restaurantName;
    private String address;
    private double rating;

    // No-arg constructor
    public Restaurant() {}

    // Constructor used in MAIN
    public Restaurant(String restaurantName, String address, double rating) {
        this.restaurantName = restaurantName;
        this.address = address;
        this.rating = rating;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
