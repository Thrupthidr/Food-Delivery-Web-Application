package com.tap.model;

public class CartItem {

    private Menu menu;
    private int quantity;

    public CartItem(Menu menu) {
        this.menu = menu;
        this.quantity = 1;
    }

    public Menu getMenu() {
        return menu;
    }

    public int getQuantity() {
        return quantity;
    }

    public void increment() {
        quantity++;
    }

    public void decrement() {
        if (quantity > 1) {
            quantity--;
        }
    }

    public double getTotalPrice() {
        return menu.getPrice() * quantity;
    }
}
