package com.tap.servlets;

import java.io.IOException;
import java.util.List;

import com.tap.dao.RestaurantDAO;
import com.tap.dao.impl.RestaurantDAOImpl;
import com.tap.model.Restaurant;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/home")
public class RestaurantServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Use DAO interface (BEST PRACTICE)
        RestaurantDAO dao = new RestaurantDAOImpl();

        // Fetch all restaurants
        List<Restaurant> restaurants = dao.getAllRestaurants();

        // Send data to JSP
        request.setAttribute("restaurants", restaurants);

        // Forward to JSP
        RequestDispatcher rd =
                request.getRequestDispatcher("restaurant.jsp");
        rd.forward(request, response);
    }
}
