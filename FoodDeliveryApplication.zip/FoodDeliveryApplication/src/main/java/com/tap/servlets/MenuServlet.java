package com.tap.servlets;

import java.io.IOException;
import javax.servlet.http.HttpSession;

import java.util.List;

import com.tap.dao.impl.MenuDAOImpl;
import com.tap.model.Menu;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // 1. Read restaurantId from URL
        int restaurantId =
                Integer.parseInt(req.getParameter("restaurantId"));
        HttpSession session = req.getSession();
        session.setAttribute("restaurantId", restaurantId);


        //  DAO call
        MenuDAOImpl dao = new MenuDAOImpl();
        List<Menu> menuList = dao.getMenusByRestaurant(restaurantId);

        //  Send data to JSP
        req.setAttribute("menuList", menuList);

        // Forward to menu.jsp
        RequestDispatcher rd =
                req.getRequestDispatcher("menu.jsp");
        rd.forward(req, resp);
    }
}
