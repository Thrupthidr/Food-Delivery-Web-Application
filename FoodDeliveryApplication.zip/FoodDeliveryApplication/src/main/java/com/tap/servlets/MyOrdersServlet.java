package com.tap.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tap.dao.impl.OrdersDAOImpl;
import com.tap.model.Orders;
import com.tap.model.User;

@WebServlet("/my-orders")
public class MyOrdersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // ✅ if not logged in
        if (user == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        OrdersDAOImpl dao = new OrdersDAOImpl();
        List<Orders> ordersList = dao.getOrdersByUser(user.getUserId());

        req.setAttribute("ordersList", ordersList);

        RequestDispatcher rd =
                req.getRequestDispatcher("myorders.jsp");
        rd.forward(req, resp);
    }
}
