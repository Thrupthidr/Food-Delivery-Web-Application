package com.tap.servlets;

import java.io.IOException;

import com.tap.dao.impl.UserDAOImpl;
import com.tap.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        UserDAOImpl dao = new UserDAOImpl();
        User user = dao.getUserByEmail(email);

        if (user != null && user.getPassword().equals(password)) {

            // ✅ create session
            HttpSession session = req.getSession(true);
            session.setAttribute("user", user);

            // ✅ FIXED REDIRECT
            resp.sendRedirect(req.getContextPath() + "/home");

        } else {
            // ❌ invalid login
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }
}