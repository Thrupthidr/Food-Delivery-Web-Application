package com.tap.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.impl.MenuDAOImpl;
import com.tap.model.CartItem;
import com.tap.model.Menu;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/add-to-cart")
public class AddToCartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // 1️⃣ Read menuId from form
        int menuId = Integer.parseInt(req.getParameter("menuId"));

        // 2️⃣ Get Menu from DB
        MenuDAOImpl dao = new MenuDAOImpl();
        Menu menu = dao.getMenu(menuId);

        // 3️⃣ Get session
        HttpSession session = req.getSession();

        // 4️⃣ Get cart from session
        List<CartItem> cart =
                (List<CartItem>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        // 5️⃣ Check if item already exists
        boolean found = false;

        for (CartItem item : cart) {
            if (item.getMenu().getMenuId() == menuId) {
                item.increment();   // quantity +1
                found = true;
                break;
            }
        }

        // 6️⃣ If new item, add to cart
        if (!found) {
            cart.add(new CartItem(menu));
        }

        // 7️⃣ Save cart back to session
        session.setAttribute("cart", cart);

        // 8️⃣ Redirect to cart page
        resp.sendRedirect("cart.jsp");
    }
}
