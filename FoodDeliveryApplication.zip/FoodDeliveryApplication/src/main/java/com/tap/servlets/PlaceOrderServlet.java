package com.tap.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tap.dao.impl.OrderItemDAOImpl;
import com.tap.dao.impl.OrdersDAOImpl;
import com.tap.model.CartItem;
import com.tap.model.OrderItem;
import com.tap.model.Orders;
import com.tap.model.User;

@WebServlet("/place-order")
public class PlaceOrderServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        // 1️⃣ Get session data
        User user = (User) session.getAttribute("user");
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        Integer restaurantId = (Integer) session.getAttribute("restaurantId");

        // 2️⃣ Validations
        if (user == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        if (cart == null || cart.isEmpty()) {
            resp.sendRedirect("cart.jsp");
            return;
        }

        if (restaurantId == null) {
            resp.sendRedirect("home");
            return;
        }

        // 3️⃣ Read form data
        String address = req.getParameter("address");
        String paymentMethod = req.getParameter("paymentMethod");

        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            paymentMethod = "COD";
        }

        // 4️⃣ Calculate total amount
        double totalAmount = 0;
        for (CartItem item : cart) {
            totalAmount += item.getTotalPrice();
        }

        // 5️⃣ Create Order
        Orders order = new Orders();
        order.setUserId(user.getUserId());
        order.setRestaurantId(restaurantId);
        order.setTotalAmount(totalAmount);
        order.setDeliveryAddress(address);
        order.setPaymentMethod(paymentMethod);
        order.setOrderStatus("PLACED");

        // 6️⃣ Save Order
        OrdersDAOImpl ordersDAO = new OrdersDAOImpl();
        int orderId = ordersDAO.addOrder(order);

        // 🚨 MUST CHECK
        if (orderId <= 0) {
            System.out.println("❌ Order not created");
            resp.sendRedirect("cart.jsp");
            return;
        }

        System.out.println("✅ Order created with ID: " + orderId);

        // 7️⃣ Save Order Items
        OrderItemDAOImpl itemDAO = new OrderItemDAOImpl();

        for (CartItem item : cart) {

            if (item.getMenu() == null) {
                System.out.println("❌ Menu object is NULL");
                continue;
            }

            int menuId = item.getMenu().getMenuId();

            if (menuId <= 0) {
                System.out.println("❌ Invalid menuId");
                continue;
            }

            OrderItem oi = new OrderItem();
            oi.setOrderId(orderId);
            oi.setMenuId(menuId);
            oi.setQuantity(item.getQuantity());
            oi.setItemTotal(item.getTotalPrice());

            int result = itemDAO.addOrderItem(oi);
            System.out.println("✅ OrderItem insert result: " + result);
        }

        // 8️⃣ Clear session
        session.removeAttribute("cart");
        session.removeAttribute("restaurantId");

        // 9️⃣ Redirect to success page
        resp.sendRedirect("order-success.jsp");
    }
}
