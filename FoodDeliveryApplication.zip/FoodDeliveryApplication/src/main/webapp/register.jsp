<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/style.css">
</head>
<body>

<!-- HEADER -->
<div class="header">
    <div class="logo">
        🍔 Food Delivery
    </div>
    <div class="nav-links">
        <a href="<%=request.getContextPath()%>/home">Home</a>
        <a href="<%=request.getContextPath()%>/login.jsp">Login</a>
    </div>
</div>

<!-- REGISTRATION CARD -->
<div class="form-container">
    <h2>User Registration</h2>

    <form action="<%=request.getContextPath()%>/register" method="post">

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter username" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Enter email" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password" required>
        </div>

        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" placeholder="Enter address" required>
        </div>

        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" placeholder="Enter phone number" required>
        </div>

        <button type="submit" class="btn-primary">Register</button>
    </form>

    <p class="form-footer">
        Already registered?
        <a href="<%=request.getContextPath()%>/login.jsp">Login here</a>
    </p>
</div>

</body>
</html>
