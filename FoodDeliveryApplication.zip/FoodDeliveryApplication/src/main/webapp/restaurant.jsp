<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.tap.model.Restaurant" %>

<!DOCTYPE html>
<html>
<head>
    <title>Restaurants</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>
        <a href="home">🏠 Home</a>
        <a href="my-orders">📦 My Orders</a>
    </div>
    <a href="logout">🚪 Logout</a>
</div>

<h1 class="heading">Restaurants</h1>

<!-- RESTAURANT LIST -->
<div class="restaurant-container">

<%
    List<Restaurant> restaurants =
        (List<Restaurant>) request.getAttribute("restaurants");

    if (restaurants == null || restaurants.isEmpty()) {
%>
        <p style="text-align:center;">No restaurants found</p>
<%
    } else {
        for (Restaurant r : restaurants) {
%>
            <div class="restaurant-card">
                <h3><%= r.getRestaurantName() %></h3>
                <p>📍 <%= r.getAddress() %></p>
                <p>⭐ Rating: <%= r.getRating() %></p>

                <a href="menu?restaurantId=<%= r.getRestaurantId() %>">
                    View Menu
                </a>
            </div>
<%
        }
    }
%>

</div>

</body>
</html>
