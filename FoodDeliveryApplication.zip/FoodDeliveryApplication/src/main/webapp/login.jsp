<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">🍔 Food Delivery</div>
    <div>
        <a href="<%= request.getContextPath() %>/home">Home</a>
        <a href="<%= request.getContextPath() %>/my-orders">My Orders</a>
        <a href="<%= request.getContextPath() %>/logout">Logout</a>
    </div>
</div>

<!-- CENTERED LOGIN BOX -->
<div class="auth-container">
    <div class="auth-card">

        <h2>User Login</h2>

        <form action="<%= request.getContextPath() %>/login" method="post">

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn">Login</button>
        </form>

        <p class="auth-footer">
            New user?
            <a href="<%= request.getContextPath() %>/register.jsp">Register here</a>
        </p>

    </div>
</div>

</body>
</html>
