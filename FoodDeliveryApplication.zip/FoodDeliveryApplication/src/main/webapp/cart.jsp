<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.tap.model.CartItem" %>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">🍔 Food Delivery</div>
    <div>
        <a href="<%= request.getContextPath() %>/home">Home</a>
        <a href="<%= request.getContextPath() %>/my-orders">My Orders</a>
        <a href="<%= request.getContextPath() %>/logout">Logout</a>
    </div>
</div>

<h1 class="heading">Your Cart</h1>

<div class="cart-container">

<%
    List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

    if (cart == null || cart.isEmpty()) {
%>
        <p style="text-align:center;">Your cart is empty</p>
<%
    } else {
        double total = 0;

        for (CartItem item : cart) {
            total += item.getTotalPrice();
%>
        <div class="cart-card">
            <div class="cart-info">
                <h3><%= item.getMenu().getMenuName() %></h3>
                <p>Price: ₹<%= item.getMenu().getPrice() %></p>
                <p>Quantity: <%= item.getQuantity() %></p>
            </div>

            <div class="cart-total">
                ₹<%= item.getTotalPrice() %>
            </div>
        </div>
<%
        }
%>
</div>

<div class="cart-summary">
    <h2>Total: ₹<%= total %></h2>

    <form action="<%= request.getContextPath() %>/place-order" method="post">
        <button type="submit" class="btn">Place Order</button>
    </form>

    <a href="<%= request.getContextPath() %>/home" class="back-link">
        ⬅ Back to Restaurants
    </a>
</div>

<%
    }
%>

</body>
</html>
