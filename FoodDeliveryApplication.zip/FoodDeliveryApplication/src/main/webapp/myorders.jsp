<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.tap.model.Orders" %>

<!DOCTYPE html>
<html>
<head>
    <title>My Orders</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">🍔 Food Delivery</div>
    <div>
        <a href="<%= request.getContextPath() %>/home">Home</a>
        <a href="<%= request.getContextPath() %>/my-orders">My Orders</a>
        <a href="<%= request.getContextPath() %>/logout">Logout</a>
    </div>
</div>

<h1 class="heading">📦 My Orders</h1>

<div class="orders-container">

<%
    List<Orders> ordersList =
        (List<Orders>) request.getAttribute("ordersList");

    if (ordersList == null || ordersList.isEmpty()) {
%>
        <p style="text-align:center;">No orders found.</p>
<%
    } else {
        for (Orders o : ordersList) {
%>
    <div class="order-card">

        <div class="order-row">
            <span>Order ID</span>
            <strong>#<%= o.getOrderId() %></strong>
        </div>

        <div class="order-row">
            <span>Total</span>
            <strong>₹ <%= o.getTotalAmount() %></strong>
        </div>

        <div class="order-row">
            <span>Status</span>
            <span class="status"><%= o.getOrderStatus() %></span>
        </div>

        <div class="order-row">
            <span>Payment</span>
            <span><%= o.getPaymentMethod() %></span>
        </div>

        <div class="order-row">
            <span>Date</span>
            <span><%= o.getOrderDate() %></span>
        </div>

    </div>
<%
        }
    }
%>

</div>

</body>
</html>
