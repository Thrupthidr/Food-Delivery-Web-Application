<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.tap.model.Menu" %>

<!DOCTYPE html>
<html>
<head>
    <title>Menu</title>
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/style.css">
</head>

<body>

<!-- HEADER -->
<div class="header">
    <div>
        <strong>🍔 Food Delivery</strong>
    </div>
    <div>
        <a href="<%=request.getContextPath()%>/home">Home</a>
        <a href="<%=request.getContextPath()%>/my-orders">My Orders</a>
        <a href="<%=request.getContextPath()%>/logout">Logout</a>
    </div>
</div>

<!-- PAGE TITLE -->
<div class="container">
    <h1>Menu Items</h1>

<%
    List<Menu> menuList = (List<Menu>) request.getAttribute("menuList");

    if (menuList == null || menuList.isEmpty()) {
%>
        <p>No menu items found</p>
<%
    } else {
%>

    <!-- MENU GRID -->
    <div class="menu-grid">

<%
        for (Menu m : menuList) {
%>
        <!-- MENU CARD -->
        <div class="card">
            <h3><%= m.getMenuName() %></h3>
            <p><%= m.getDescription() %></p>
            <p class="price">₹ <%= m.getPrice() %></p>
            <p>⭐ <%= m.getRating() %></p>

            <!-- ADD TO CART -->
            <form action="<%=request.getContextPath()%>/add-to-cart" method="post">
                <input type="hidden" name="menuId" value="<%= m.getMenuId() %>">
                <button type="submit" class="btn">Add to Cart</button>
            </form>
        </div>

<%
        }
%>
    </div> <!-- menu-grid -->

<%
    }
%>

</div> <!-- container -->

</body>
</html>
