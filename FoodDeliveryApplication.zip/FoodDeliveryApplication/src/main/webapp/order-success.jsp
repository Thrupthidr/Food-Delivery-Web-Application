<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Order Success</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">🍔 Food Delivery</div>
    <div>
        <a href="<%= request.getContextPath() %>/home">Home</a>
        <a href="<%= request.getContextPath() %>/my-orders">My Orders</a>
        <a href="<%= request.getContextPath() %>/logout">Logout</a>
    </div>
</div>

<!-- SUCCESS MESSAGE -->
<div class="success-container">
    <div class="success-card">

        <div class="success-icon">🎉</div>

        <h1>Order Placed Successfully!</h1>
        <p>Your order has been placed successfully and is being prepared.</p>

        <div class="success-actions">
            <a href="<%= request.getContextPath() %>/my-orders" class="btn">
                View My Orders
            </a>

            <a href="<%= request.getContextPath() %>/home" class="back-link">
                Go to Home
            </a>
        </div>

    </div>
</div>

</body>
</html>
